function imc() {
    var peso = prompt("Introduzca su peso (kg):",);
    var altura = prompt("Introduzca su altura en centímetros: ",);
    var imc = peso / ((altura* 0.01) ** 2);
    document.getElementById("contenido").innerHTML=imc.toFixed(2);
    document.getElementById("Contenido").innerHTML= "<ul>" +
    "<li> < 16.00: Infrapeso (delgadez severa)</li>" + 
    "<li> 16.00 – 16.99: Infrapeso (delgadez moderada)</li>" + 
    "<li> 17.00 - 18.49: Infrapeso (delgadez aceptable)</li>" + 
    "<li> 18.50 - 24.99: Peso normal</li>" + 
    "<li> 25.00 - 29.99: Sobrepeso</li>" + 
    "<li> 30.00 - 34.99: Obeso (Tipo I)</li>" + 
    "<li> 35.00 - 40.00: Obeso (Tipo II)</li>" +
    "<li> >40.00: Obeso (Tipo III)</li>" +
    "</ul>"
    
}


