<html>
<head>
	<title>Prueba de PHP</title>
</head>
<body>
	<?php
	 echo '<p>Sagitario <br/> Real Madrid</p>';
	 ?>

</body>
</html>
