<html>
<head>
	<title>Prueba de PHP</title>
</head>
<body>
	<?php
	//Número 1
	$x = 144;
	//Número 2
	$y  = 999;
	/*
	Author:
	Juan Miguel
	Costa Lucena
	*/
	echo "<p>$x</p>";
	echo "<p>$y</p>";
	?>

	<ul>
		<li><?php echo $x + $y?></li>	
		<li><?php echo $x - $y?></li>
		<li><?php echo $x / $y?></li>
		<li><?php echo $x * $y?></li>
	</ul>
</body>
</html>
