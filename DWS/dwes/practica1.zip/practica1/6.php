<html>
<head>
	<title>Prueba de PHP</title>
</head>
<body>
	<?php
	$nombre = "Juan Miguel";
	$horoscopo = "Sagitario";
	$equipo_futbol = "Real Madrid";
	echo "<p>$horoscopo <br/> $equipo_futbol <br/> $nombre</p>";
	?>
</body>
</html>
