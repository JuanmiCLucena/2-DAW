<html>
<head>
	<title>Prueba de PHP</title>
</head
<body>
	<?php echo '<p>Juan Miguel Costa Lucena</p>'; ?>
</body>
</html>
