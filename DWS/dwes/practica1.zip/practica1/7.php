<html>
<head>
	<title>Prueba de PHP</title>
</head>
<body>
	<?php
	$euros = 100;
	$dolares = $euros * 1.16;
	printf('%0.2f', $dolares); 	
	 ?>
</body>
</html>
