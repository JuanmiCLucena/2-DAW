<html>
<head>
	<title>Prueba de PHP</title>
</head>
<body>
	<?php
	echo "<p>*</p>";		
	echo "<p>**</p>";		
	echo "<p>***</p>";		
	echo "<p>****</p>";		
	echo "<p>*****</p>";		
	echo "<p>******</p>";		
	echo "<p>*******</p>";		
	echo "<p>********</p>";		
	echo "<p>*********</p>";		
	?>
</body>
</html>
