<html>
<head>
	<title>Prueba de PHP</title>
</head>
	<?php
	$v0 = 50;
	$t = 3;
	$a = 23;
	$d = $v0 * $t + 0.5 * $a * $t ** 2;
	echo "<p>$v0</p>";
	echo "<p>$t</p>";
	echo "<p>$a</p>";
	echo "<p>$d</p>";
	?>
</body>
</html>
