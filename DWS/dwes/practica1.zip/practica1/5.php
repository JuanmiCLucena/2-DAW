<html>
<head>
	<title>Prueba de PHP</title>
</head>
<body>
	<?php
	$nombre = "Juan Miguel";
	$apellido = "Costa";
	echo "<p>$nombre $apellido</p>";
	?>
</body>
</html>
