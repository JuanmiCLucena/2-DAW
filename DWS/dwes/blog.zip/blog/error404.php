<?php
theHeader("Página no encontrada");
?>
<h2>Error 404</h2>
<h3>Página no encontrada</h3>
<?php
theFooter();
